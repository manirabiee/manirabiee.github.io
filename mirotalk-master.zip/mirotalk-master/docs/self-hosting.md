# MiroTalk P2P - Self Hosting

### How can I self-host MiroTalk P2P on my own server?

[https://docs.mirotalk.com/mirotalk-p2p/self-hosting/](https://docs.mirotalk.com/mirotalk-p2p/self-hosting/)

---

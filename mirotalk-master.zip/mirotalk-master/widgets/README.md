# MiroTalk Widgets

![widget](./widget.png)

---

This directory contains embeddable example widgets for MiroTalk that can be integrated into any website or application.
